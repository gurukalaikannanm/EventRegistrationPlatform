package com.ortmor.task.backendregistration.model;


import jakarta.persistence.*;
import org.springframework.data.annotation.Id;


import java.util.List;

@Entity
@Table(name = "departments")
public class Department {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "department_name")
    private String departmentName;

    @Column(name = "registration_capacity")
    private Integer registrationCapacity;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDepartmentName() {
        return departmentName;
    }

    public void setDepartmentName(String departmentName) {
        this.departmentName = departmentName;
    }

    public Integer getRegistrationCapacity() {
        return registrationCapacity;
    }

    public void setRegistrationCapacity(Integer registrationCapacity) {
        this.registrationCapacity = registrationCapacity;
    }

    public List<Registration> getRegistrations() {
        return registrations;
    }

    public void setRegistrations(List<Registration> registrations) {
        this.registrations = registrations;
    }

    @OneToMany(mappedBy = "department")
    private List<Registration> registrations;


}
