package com.ortmor.task.backendregistration.component;

import com.ortmor.task.backendregistration.model.Registration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Component;

import javax.mail.internet.InternetAddress;


@Component
public class EmailSender {

    @Autowired
    private JavaMailSender emailSender;

    public void sendRegistrationConfirmationEmail(Registration registration) {
        jakarta.mail.internet.MimeMessage message = emailSender.createMimeMessage();
        try {
            message.setFrom(String.valueOf(new InternetAddress("noreply@department-registration.com")));
            message.setRecipients(jakarta.mail.Message.RecipientType.TO, String.valueOf(InternetAddress.parse(registration.getEmail())));
            message.setSubject("Department Registration Confirmation");
            message.setText(String.format("Dear %s,\n" +
                            "This email confirms your registration for the %s department.\n" +
                            "Registration timestamp: %s\n" +
                            "Please arrive at the event location at the specified time.\n" +
                            "Sincerely,\n" +
                            "Department Registration Team",
                    registration.getName(), registration.getDepartment().getDepartmentName(),
                    registration.getRegistrationTimestamp()));

            emailSender.send(message);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
