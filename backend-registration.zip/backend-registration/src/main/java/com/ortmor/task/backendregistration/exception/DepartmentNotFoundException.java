package com.ortmor.task.backendregistration.exception;

public class DepartmentNotFoundException extends RuntimeException {

    public DepartmentNotFoundException(Long departmentId) {
        super("Department with ID " + departmentId + " not found.");
    }
}
