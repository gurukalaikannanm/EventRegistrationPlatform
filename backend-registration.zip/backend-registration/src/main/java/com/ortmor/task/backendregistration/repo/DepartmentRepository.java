package com.ortmor.task.backendregistration.repo;

import com.ortmor.task.backendregistration.model.Department;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface DepartmentRepository extends JpaRepository<Department, Long> {

    List<Department> findAll();

    Optional<Department> findById(Long id);

    Department save(Department department);

    void deleteById(Long id);

    boolean existsById(Long id);

    @Query("SELECT COUNT(r) FROM Registration r WHERE r.department.id = ?1")
    int countRegistrationsByDepartmentId(Long departmentId);

    @Query("SELECT d FROM Department d WHERE d.registrationCapacity > (SELECT COUNT(r) FROM Registration r WHERE r.department.id = ?1)")
    List<Department> findDepartmentsWithAvailableCapacity(Long departmentId);

    @Query("SELECT SUM(d.registrationCapacity) FROM Department d")
    int getTotalRegistrationCapacity();

    @Query("SELECT COUNT(r) FROM Registration r")
    int getTotalRegistrations();
}
