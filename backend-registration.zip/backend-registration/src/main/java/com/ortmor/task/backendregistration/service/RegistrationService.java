package com.ortmor.task.backendregistration.service;


import com.ortmor.task.backendregistration.component.EmailSender;
import com.ortmor.task.backendregistration.exception.DepartmentFullException;
import com.ortmor.task.backendregistration.exception.DepartmentNotFoundException;
import com.ortmor.task.backendregistration.model.Department;
import com.ortmor.task.backendregistration.model.Registration;
import com.ortmor.task.backendregistration.repo.DepartmentRepository;
import com.ortmor.task.backendregistration.repo.RegistrationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.util.List;

@Service
public class RegistrationService {

    private final DepartmentRepository departmentRepository;
    private final RegistrationRepository registrationRepository;
    private final EmailSender emailSender;

    @Autowired
    public RegistrationService(
            DepartmentRepository departmentRepository,
            RegistrationRepository registrationRepository,
            EmailSender emailSender) {
        this.departmentRepository = departmentRepository;
        this.registrationRepository = registrationRepository;
        this.emailSender = emailSender;
    }

    public List<Department> getAllDepartments() {
        return departmentRepository.findAll();
    }

    public void register(Long departmentId, Registration registration) {
        Department department = departmentRepository.findById(departmentId)
                .orElseThrow(() -> new DepartmentNotFoundException(departmentId));

        if (departmentIsFull(department)) {
            throw new DepartmentFullException(departmentId);
        }

        registerParticipant(registration, department);

        sendRegistrationConfirmationEmail(registration);
    }

    private boolean departmentIsFull(Department department) {
        return department.getRegistrationCapacity() <= department.getRegistrations().size();
    }

    private void registerParticipant(Registration registration, Department department) {
        registration.setDepartment(department);
        registration.setRegistrationTimestamp(new Timestamp(System.currentTimeMillis()));
        registrationRepository.save(registration);
    }

    private void sendRegistrationConfirmationEmail(Registration registration) {
        emailSender.sendRegistrationConfirmationEmail(registration);
    }
}
