package com.ortmor.task.backendregistration.exception;

public class DepartmentFullException extends RuntimeException {

    public DepartmentFullException(Long departmentId) {
        super("Department with ID " + departmentId + " is full.");
    }
}
