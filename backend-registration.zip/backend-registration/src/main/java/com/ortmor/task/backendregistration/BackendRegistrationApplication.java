package com.ortmor.task.backendregistration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendRegistrationApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendRegistrationApplication.class, args);
	}

}
