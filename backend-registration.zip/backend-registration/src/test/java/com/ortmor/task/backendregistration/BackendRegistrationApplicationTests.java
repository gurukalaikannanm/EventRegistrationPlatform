package com.ortmor.task.backendregistration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendRegistrationApplicationTests {

	@Test
	void contextLoads() {
	}

}
